"""
fast_scraper.py
───────────────
Лёгкий API поверх curl_cffi для Rozetka / Prom / Epicentr / Allo / Hotline.
Без БД, без UI — только fetch + нормализованный результат.

Установка:
    pip install curl_cffi

Использование:
    from fast_scraper import scrape

    result = scrape("rozetka", "product", id="123456")
    result = scrape("allo",    "seller",  seller_id="789", page=1)
    result = scrape("prom",    "search",  query="iphone", page=1)
    result = scrape("hotline", "filtered_page", url="https://hotline.ua/...", params={...})

Возвращает всегда:
    {
        "ok": bool,
        "site": str,
        "mode": str,
        "data": dict | list | None,
        "error": str | None,
        "status_code": int | None,
    }
"""

import time
import logging
from typing import Any
from curl_cffi import requests as cffi_requests

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────
# RATE LIMITS (req/min) — консервативно
# ──────────────────────────────────────────────
_RATE = {
    "rozetka":  40,
    "prom":     25,
    "epicentr": 30,
    "allo":     15,   # самый жёсткий
    "hotline":  60,
}
_last_call: dict[str, float] = {}


def _throttle(site: str) -> None:
    min_interval = 60.0 / _RATE[site]
    elapsed = time.monotonic() - _last_call.get(site, 0)
    if elapsed < min_interval:
        time.sleep(min_interval - elapsed)
    _last_call[site] = time.monotonic()


# ──────────────────────────────────────────────
# SESSION FACTORY
# ──────────────────────────────────────────────
def _session() -> cffi_requests.Session:
    s = cffi_requests.Session(impersonate="chrome124")
    s.headers.update({
        "Accept-Language": "uk-UA,uk;q=0.9,ru;q=0.8",
        "Accept": "application/json, text/plain, */*",
    })
    return s

_SESSION: cffi_requests.Session | None = None

def _get_session() -> cffi_requests.Session:
    global _SESSION
    if _SESSION is None:
        _SESSION = _session()
    return _SESSION


# ──────────────────────────────────────────────
# RESPONSE WRAPPER
# ──────────────────────────────────────────────
def _ok(site, mode, data, status=200):
    return {"ok": True,  "site": site, "mode": mode, "data": data, "error": None, "status_code": status}

def _err(site, mode, error, status=None):
    return {"ok": False, "site": site, "mode": mode, "data": None, "error": error, "status_code": status}


# ──────────────────────────────────────────────
# INTERNAL FETCH
# ──────────────────────────────────────────────
def _get(site: str, url: str, params: dict | None = None, extra_headers: dict | None = None) -> tuple[int, Any]:
    """
    Возвращает (status_code, parsed_json | None).
    Не бросает исключения — возвращает (0, None) при сетевой ошибке.
    """
    _throttle(site)
    s = _get_session()
    try:
        r = s.get(url, params=params, headers=extra_headers, timeout=15)
        try:
            return r.status_code, r.json()
        except Exception:
            return r.status_code, r.text
    except Exception as e:
        logger.warning(f"[{site}] GET {url} failed: {e}")
        return 0, None


def _post(site: str, url: str, json_body: dict, extra_headers: dict | None = None) -> tuple[int, Any]:
    _throttle(site)
    s = _get_session()
    try:
        r = s.post(url, json=json_body, headers=extra_headers, timeout=15)
        try:
            return r.status_code, r.json()
        except Exception:
            return r.status_code, r.text
    except Exception as e:
        logger.warning(f"[{site}] POST {url} failed: {e}")
        return 0, None


# ══════════════════════════════════════════════
# ROZETKA
# ══════════════════════════════════════════════
_RZ_GW  = "https://gateway.rozetka.com.ua"
_RZ_SRH = "https://search.rozetka.com.ua"

def _rozetka(mode: str, **kw):
    site = "rozetka"

    if mode == "product":
        # kw: id (str|int)
        pid = kw["id"]
        code, data = _get(site, f"{_RZ_GW}/api/product/v2/goods/{pid}", {"lang": "ru"})
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    elif mode == "search":
        # kw: query, page=1, per_page=24
        code, data = _get(site, f"{_RZ_SRH}/api/v1/goods", {
            "text":     kw["query"],
            "page":     kw.get("page", 1),
            "per_page": kw.get("per_page", 24),
            "lang":     "ru",
        })
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    elif mode == "seller":
        # kw: seller_id, page=1, per_page=24
        # Rozetka seller = магазин. Товары магазина через catalog с фильтром seller_id.
        seller_id = kw["seller_id"]
        code, data = _get(site, f"{_RZ_GW}/api/seller/v1/shops/{seller_id}/goods", {
            "page":     kw.get("page", 1),
            "per_page": kw.get("per_page", 24),
        })
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    elif mode == "filtered_page":
        # kw: category_id, filters (dict), page=1, per_page=24, sort="popularity"
        # filters — словарь из URL-параметров, например {"producer": "apple", "price[min]": 10000}
        params = {
            "page":     kw.get("page", 1),
            "per_page": kw.get("per_page", 24),
            "sort":     kw.get("sort", "popularity"),
            "lang":     "ru",
            **(kw.get("filters") or {}),
        }
        cat = kw["category_id"]
        code, data = _get(site, f"{_RZ_GW}/api/catalog/v1/categories/{cat}/goods", params)
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    return _err(site, mode, f"Unknown mode: {mode}")


# ══════════════════════════════════════════════
# PROM.UA
# ══════════════════════════════════════════════
_PROM_GQL = "https://prom.ua/graphql"

def _prom(mode: str, **kw):
    site = "prom"

    if mode == "product":
        # kw: id (int)
        query = """
        query ProductPage($id: Int!) {
          product(id: $id) {
            id name description price currency
            images { url }
            seller { id name }
            attributes { name value }
          }
        }"""
        code, data = _post(site, _PROM_GQL, {"operationName": "ProductPage", "variables": {"id": int(kw["id"])}, "query": query})
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data.get("data", {}).get("product"), code)

    elif mode == "search":
        # kw: query, page=1, per_page=24
        query = """
        query SearchPage($search: String!, $page: Int, $per_page: Int) {
          searchProducts(search: $search, page: $page, per_page: $per_page) {
            total_count
            products { id name price currency url image { url } seller { id name } }
          }
        }"""
        code, data = _post(site, _PROM_GQL, {
            "operationName": "SearchPage",
            "variables": {"search": kw["query"], "page": kw.get("page", 1), "per_page": kw.get("per_page", 24)},
            "query": query,
        })
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data.get("data", {}).get("searchProducts"), code)

    elif mode == "seller":
        # kw: seller_id, page=1, per_page=24
        query = """
        query SellerProducts($id: Int!, $page: Int, $per_page: Int) {
          company(id: $id) {
            id name
            products(page: $page, per_page: $per_page) {
              total_count
              products { id name price currency url image { url } }
            }
          }
        }"""
        code, data = _post(site, _PROM_GQL, {
            "operationName": "SellerProducts",
            "variables": {"id": int(kw["seller_id"]), "page": kw.get("page", 1), "per_page": kw.get("per_page", 24)},
            "query": query,
        })
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data.get("data", {}).get("company"), code)

    elif mode == "filtered_page":
        # kw: query="", category_id=None, filters={}, page=1, per_page=24
        # На Prom фильтрованные страницы = поиск с доп. переменными
        query = """
        query FilteredPage($search: String, $category_id: Int, $page: Int, $per_page: Int, $filters: JSON) {
          searchProducts(search: $search, category_id: $category_id, page: $page, per_page: $per_page, filters: $filters) {
            total_count
            products { id name price currency url image { url } }
          }
        }"""
        code, data = _post(site, _PROM_GQL, {
            "operationName": "FilteredPage",
            "variables": {
                "search":      kw.get("query", ""),
                "category_id": kw.get("category_id"),
                "page":        kw.get("page", 1),
                "per_page":    kw.get("per_page", 24),
                "filters":     kw.get("filters"),
            },
            "query": query,
        })
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data.get("data", {}).get("searchProducts"), code)

    return _err(site, mode, f"Unknown mode: {mode}")


# ══════════════════════════════════════════════
# EPICENTR
# ══════════════════════════════════════════════
_EPI_API = "https://epicentrk.ua/api"
_EPI_HEADERS = {"x-requested-with": "XMLHttpRequest"}

def _epicentr(mode: str, **kw):
    site = "epicentr"

    if mode == "product":
        # kw: id
        code, data = _get(site, f"{_EPI_API}/product/{kw['id']}", extra_headers=_EPI_HEADERS)
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    elif mode == "search":
        # kw: query, page=1, per_page=24
        code, data = _get(site, f"{_EPI_API}/catalog/search", {
            "q":     kw["query"],
            "page":  kw.get("page", 1),
            "limit": kw.get("per_page", 24),
        }, extra_headers=_EPI_HEADERS)
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    elif mode == "seller":
        # kw: seller_slug, page=1, per_page=24
        # На Epicentr продавцы = магазины партнёры. Slug из URL.
        code, data = _get(site, f"{_EPI_API}/seller/{kw['seller_slug']}/products", {
            "page":  kw.get("page", 1),
            "limit": kw.get("per_page", 24),
        }, extra_headers=_EPI_HEADERS)
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    elif mode == "filtered_page":
        # kw: category_slug, filters={}, page=1, per_page=24, sort="popular"
        params = {
            "page":  kw.get("page", 1),
            "limit": kw.get("per_page", 24),
            "sort":  kw.get("sort", "popular"),
            **(kw.get("filters") or {}),
        }
        code, data = _get(site, f"{_EPI_API}/catalog/{kw['category_slug']}", params, extra_headers=_EPI_HEADERS)
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    return _err(site, mode, f"Unknown mode: {mode}")


# ══════════════════════════════════════════════
# ALLO
# ══════════════════════════════════════════════
_ALLO_API = "https://allo.ua/api/v1"
_ALLO_GQL = "https://allo.ua/graphql"
_ALLO_HEADERS = {"origin": "https://allo.ua", "referer": "https://allo.ua/"}

def _allo(mode: str, **kw):
    site = "allo"

    if mode == "product":
        # kw: id
        code, data = _get(site, f"{_ALLO_API}/product/{kw['id']}", extra_headers=_ALLO_HEADERS)
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    elif mode == "search":
        # kw: query, page=1, per_page=24
        code, data = _get(site, f"{_ALLO_API}/catalog/search", {
            "q":        kw["query"],
            "page":     kw.get("page", 1),
            "per_page": kw.get("per_page", 24),
            "lang":     "ru",
        }, extra_headers=_ALLO_HEADERS)
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    elif mode == "seller":
        # kw: seller_id, page=1, per_page=24
        code, data = _get(site, f"{_ALLO_API}/seller/{kw['seller_id']}/products", {
            "page":     kw.get("page", 1),
            "per_page": kw.get("per_page", 24),
        }, extra_headers=_ALLO_HEADERS)
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    elif mode == "filtered_page":
        # kw: category_slug, filters={}, page=1, per_page=24
        params = {
            "page":     kw.get("page", 1),
            "per_page": kw.get("per_page", 24),
            **(kw.get("filters") or {}),
        }
        code, data = _get(site, f"{_ALLO_API}/catalog/{kw['category_slug']}/products", params, extra_headers=_ALLO_HEADERS)
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    return _err(site, mode, f"Unknown mode: {mode}")


# ══════════════════════════════════════════════
# HOTLINE
# ══════════════════════════════════════════════
_HL_BASE = "https://hotline.ua"

def _hotline(mode: str, **kw):
    site = "hotline"

    if mode == "product":
        # kw: id — числовой ID из URL hotline.ua/product/CATEGORY/ID-NAME/
        code, data = _get(site, f"{_HL_BASE}/product/{kw['id']}/prices/", {"format": "json"})
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    elif mode == "search":
        # kw: query, page=1
        code, data = _get(site, f"{_HL_BASE}/search", {
            "q":      kw["query"],
            "page":   kw.get("page", 1),
            "format": "json",
        })
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    elif mode == "seller":
        # kw: seller_id, page=1
        # Hotline: продавец = магазин. Его товары через /shop/ID/
        code, data = _get(site, f"{_HL_BASE}/shop/{kw['seller_id']}/", {
            "format": "json",
            "page":   kw.get("page", 1),
        })
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    elif mode == "filtered_page":
        # kw: category_slug, filters={}, page=1, sort="price"
        # Самый простой способ — передать полный URL как есть из браузера
        # или category_slug + filters как GET-параметры
        params = {
            "format": "json",
            "page":   kw.get("page", 1),
            "order":  kw.get("sort", "price"),
            **(kw.get("filters") or {}),
        }
        # Поддержка готового URL из браузера (с фильтрами)
        if "url" in kw:
            code, data = _get(site, kw["url"], params)
        else:
            code, data = _get(site, f"{_HL_BASE}/{kw['category_slug']}/", params)
        if code != 200: return _err(site, mode, f"HTTP {code}", code)
        return _ok(site, mode, data, code)

    return _err(site, mode, f"Unknown mode: {mode}")


# ══════════════════════════════════════════════
# PUBLIC API
# ══════════════════════════════════════════════
_DISPATCHERS = {
    "rozetka":  _rozetka,
    "prom":     _prom,
    "epicentr": _epicentr,
    "allo":     _allo,
    "hotline":  _hotline,
}

def scrape(site: str, mode: str, **kw) -> dict:
    """
    Единая точка входа.

    site : "rozetka" | "prom" | "epicentr" | "allo" | "hotline"
    mode : "product" | "search" | "seller" | "filtered_page"

    Параметры по mode:
      product       — id
      search        — query, page=1, per_page=24
      seller        — seller_id (или seller_slug для epicentr), page=1, per_page=24
      filtered_page — category_id/category_slug, filters={}, page=1, per_page=24, sort=...
                      hotline дополнительно принимает url= (готовый URL из браузера)

    Всегда возвращает dict:
      { ok, site, mode, data, error, status_code }
    """
    site = site.lower().strip()
    fn = _DISPATCHERS.get(site)
    if fn is None:
        return _err(site, mode, f"Unknown site: {site}")
    try:
        return fn(mode, **kw)
    except KeyError as e:
        return _err(site, mode, f"Missing required param: {e}")
    except Exception as e:
        logger.exception(f"[{site}/{mode}] Unexpected error")
        return _err(site, mode, str(e))


def reset_session() -> None:
    """Пересоздать curl_cffi сессию (если словил бан или куки устарели)."""
    global _SESSION
    _SESSION = None
