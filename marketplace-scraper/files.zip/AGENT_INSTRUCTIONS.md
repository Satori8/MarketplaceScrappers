# AGENT INSTRUCTIONS: Внедрение fast_scraper в существующий проект

## Контекст

В проекте уже есть парсер на основе браузера (Playwright/Selenium) или `requests`.
Задача: добавить `fast_scraper.py` как **быстрый первичный метод**, оставив старый как fallback.

---

## Шаг 1 — Установить зависимость

```bash
pip install curl_cffi
```

Добавить в `requirements.txt`:
```
curl_cffi>=0.7
```

---

## Шаг 2 — Разместить файл

Скопировать `fast_scraper.py` в директорию со scrapers проекта, например:
```
src/scrapers/fast_scraper.py
```

---

## Шаг 3 — Найти место вызова старого парсера

В существующем коде найти функции/методы, которые делают парсинг.
Типичные паттерны, которые нужно искать:
- `get_product(...)`, `fetch_product(...)`
- `parse_page(...)`, `scrape_url(...)`
- любые вызовы `requests.get(url)`, `browser.goto(url)`, `driver.get(url)`

---

## Шаг 4 — Обернуть по паттерну Fast → Fallback

### Принцип
```python
result = fast_scraper.scrape(site, mode, **params)

if result["ok"]:
    return normalize(result["data"])   # новый путь
else:
    log.warning(f"fast_scraper failed: {result['error']}, falling back")
    return legacy_scrape(...)          # старый путь без изменений
```

### Пример: карточка товара

**До (старый код):**
```python
def get_product(url: str) -> dict:
    browser.goto(url)
    return parse_html(browser.content())
```

**После:**
```python
from src.scrapers.fast_scraper import scrape, reset_session

def get_product(site: str, product_id: str, url: str) -> dict:
    result = scrape(site, "product", id=product_id)

    if result["ok"]:
        return normalize_product(result["data"], site)

    # Fallback — старый метод без изменений
    logger.warning(f"[fast_scraper] {result['error']} — using legacy for {url}")
    browser.goto(url)
    return parse_html(browser.content())
```

### Пример: товары продавца

```python
def get_seller_products(site: str, seller_id: str, page: int = 1) -> list:
    result = scrape(site, "seller", seller_id=seller_id, page=page)

    if result["ok"]:
        return normalize_product_list(result["data"], site)

    # Fallback
    return legacy_get_seller_products(seller_id, page)
```

### Пример: страница с фильтрами

```python
def get_filtered_page(site: str, category_slug: str, filters: dict, page: int = 1) -> list:
    result = scrape(site, "filtered_page",
                    category_slug=category_slug,
                    filters=filters,
                    page=page)

    if result["ok"]:
        return normalize_product_list(result["data"], site)

    # Fallback — передать оригинальный URL из браузера
    return legacy_get_filtered_page(url=build_url(category_slug, filters, page))
```

---

## Шаг 5 — Нормализация данных

Каждый сайт возвращает разную структуру в `result["data"]`.
Нужно написать адаптеры под схему данных проекта.

Пример скелета нормализатора:

```python
def normalize_product(data: dict, site: str) -> dict:
    """Приводит data из fast_scraper к внутренней схеме проекта."""
    if site == "rozetka":
        return {
            "id":    data.get("id"),
            "title": data.get("title"),
            "price": data.get("price"),
            "url":   data.get("href"),
            # ... остальные поля по схеме проекта
        }
    elif site == "prom":
        return {
            "id":    data.get("id"),
            "title": data.get("name"),
            "price": data.get("price"),
            "url":   data.get("url"),
        }
    elif site == "allo":
        return {
            "id":    data.get("id"),
            "title": data.get("title"),
            "price": data.get("price"),
            "url":   data.get("slug"),
        }
    # epicentr, hotline — аналогично
    raise ValueError(f"Unknown site: {site}")
```

**Как заполнить поля нормализатора:**
1. Запустить `scrape(site, "product", id="любой_тестовый_id")`
2. Распечатать `result["data"]` — увидеть реальную структуру
3. Замапить поля на схему проекта

---

## Шаг 6 — Обработка сессионных банов

Если несколько запросов подряд вернули `status_code=403` или `status_code=429`:

```python
from src.scrapers.fast_scraper import scrape, reset_session

CONSECUTIVE_FAILS = 0
MAX_FAILS = 5

def scrape_with_recovery(site, mode, **kw):
    global CONSECUTIVE_FAILS
    result = scrape(site, mode, **kw)

    if not result["ok"] and result["status_code"] in (403, 429):
        CONSECUTIVE_FAILS += 1
        if CONSECUTIVE_FAILS >= MAX_FAILS:
            reset_session()          # пересоздаёт curl_cffi сессию
            CONSECUTIVE_FAILS = 0
            time.sleep(30)           # пауза перед повтором
    else:
        CONSECUTIVE_FAILS = 0

    return result
```

---

## Шаг 7 — Логирование (опционально, но рекомендуется)

Добавить в конфиг логгера проекта:

```python
logging.getLogger("fast_scraper").setLevel(logging.WARNING)
```

Для дебага временно:
```python
logging.getLogger("fast_scraper").setLevel(logging.DEBUG)
```

---

## Параметры scrape() по режимам — шпаргалка

| mode            | обязательные params              | опциональные                        |
|-----------------|----------------------------------|-------------------------------------|
| `product`       | `id`                             | —                                   |
| `search`        | `query`                          | `page`, `per_page`                  |
| `seller`        | `seller_id` (epicentr: `seller_slug`) | `page`, `per_page`             |
| `filtered_page` | `category_id` или `category_slug` | `filters` (dict), `page`, `per_page`, `sort`, `url` (hotline) |

---

## Что НЕ менять

- Схему БД
- Модели данных
- UI / отображение
- Логику планировщика / очереди задач
- Старый scraper — он остаётся как есть

Единственное изменение в проекте: **обернуть вызовы парсинга** по паттерну из Шага 4.

---

## Признаки успешного внедрения

- `result["ok"] == True` на тестовых товарах всех 5 сайтов
- Старый код не вызывается для успешных запросов
- В логах нет `fast_scraper failed` при нормальной работе
- Прирост скорости: ~10–30x по сравнению с браузером
